use spyglass;
use SpyGlass;
use SpyGlass::Objects;
&spyGenerateDelViolHash("./proName/fifo/lint/lint_rtl/spyglass_spysch/sg_msgtag.txt");
1;