#!/bin/sh
cd /home/m112/m112061527/fifo/lint
spyglass -project proName.prj -goal lint/lint_rtl & 
