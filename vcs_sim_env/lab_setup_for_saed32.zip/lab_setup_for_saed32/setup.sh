## produce dir
mkdir upload

mkdir results

mkdir reports

mkdir lab_synthesis

mkdir ./lab_synthesis/work
mkdir ./lab_synthesis/system
mkdir ./lab_synthesis/system/hex
mkdir ./lab_synthesis/system/env

mkdir ./lab_synthesis/sim_vcs
mkdir ./lab_synthesis/sim_vcs/env
mkdir ./lab_synthesis/sim_vcs_edge

mkdir ./lab_synthesis/scripts


mkdir input

mkdir common
mkdir ./common/caravel_project
mkdir ./common/caravel_project/rtl
mkdir ./common/caravel_project/rtl/verilog

echo "mkdir done"


## copy file from lab_formal_release

cp ../lab_formal_release/makefile makefile
cp ../lab_formal_release/common/common.tcl ./common/common.tcl
cp ../lab_formal_release/common/common.tcl.saed32 ./common/common.tcl.saed32
cp ../lab_formal_release/lab_synthesis/scripts/compile_for_timing.tcl.caravel ./lab_synthesis/scripts/compile_for_timing.tcl.caravel
cp ../lab_formal_release/lab_synthesis/sim_vcs/env/bfm.lib.f.saed32 ./lab_synthesis/sim_vcs/env/bfm.lib.f.saed32
cp ../lab_formal_release/lab_synthesis/system/env/bfm.lib.f.saed32 ./lab_synthesis/system/env/bfm.lib.f.saed32
cp ../lab_formal_release/common/caravel_project/rtl/verilog/synthesis_defines.v.saed32 ./common/caravel_project/rtl/verilog/synthesis_defines.v.saed32

cp ../lab_formal_release/lab_synthesis/makefile ./lab_synthesis/makefile
cp ../lab_formal_release/lab_synthesis/sim_vcs_edge/makefile ./lab_synthesis/sim_vcs_edge/makefile
cp ../lab_formal_release/lab_synthesis/system/top_bench.sv ./lab_synthesis/system/top_bench.sv
cp ../lab_formal_release/lab_synthesis/system/hex/system_test111.hex ./lab_synthesis/system/hex/system_test111.hex
cp ../lab_formal_release/lab_synthesis/system/hex/system_test112.hex ./lab_synthesis/system/hex/system_test112.hex
cp ../lab_formal_release/lab_synthesis/system/hex/system_test103.hex ./lab_synthesis/system/hex/system_test103.hex
cp ../lab_formal_release/lab_synthesis/system/hex/system_test104.hex ./lab_synthesis/system/hex/system_test104.hex
cp ../lab_formal_release/lab_synthesis/system/hex/system_test113.hex ./lab_synthesis/system/hex/system_test113.hex
cp ../lab_formal_release/lab_synthesis/system/hex/system_test114.hex ./lab_synthesis/system/hex/system_test114.hex

cp ../lab_formal_release/lab_synthesis/system/env/bfm.sys.f ./lab_synthesis/system/env/bfm.sys.f
cp ../lab_formal_release/lab_synthesis/system/env/cpu_trace.v ./lab_synthesis/system/env/cpu_trace.v
cp ../lab_formal_release/lab_synthesis/system/env/dasm.v ./lab_synthesis/system/env/dasm.v


cp -rf ../lab_formal_release/lab_synthesis/system/models ./lab_synthesis/system/models

cp ../lab_formal_release/lab_synthesis/system/caravel.f ./lab_synthesis/system/caravel.f

cp ../lab_formal_release/lab_synthesis/system/makefile ./lab_synthesis/system/makefile
cp ../lab_formal_release/lab_synthesis/work/Makefile ./lab_synthesis/work/Makefile
cp ../lab_formal_release/common/caravel_top_analyze.tcl ./common/caravel_top_analyze.tcl
cp ../lab_formal_release/common/caravel_top.sdc ./common/caravel_top.sdc
cp ../lab_formal_release/common/warnings_to_ignore.tcl ./common/warnings_to_ignore.tcl



cp ../lab_formal_release/common/caravel_project/rtl/verilog/defines.v ./common/caravel_project/rtl/verilog/defines.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/user_defines.v ./common/caravel_project/rtl/verilog/user_defines.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/pads.wire.v ./common/caravel_project/rtl/verilog/pads.wire.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/RAM256.v ./common/caravel_project/rtl/verilog/RAM256.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/RAM128.v ./common/caravel_project/rtl/verilog/RAM128.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/fsic_iopad.v ./common/caravel_project/rtl/verilog/fsic_iopad.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/sky130_fd_sc.v ./common/caravel_project/rtl/verilog/sky130_fd_sc.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/reset_as_por.v ./common/caravel_project/rtl/verilog/reset_as_por.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/axil_axis.v ./common/caravel_project/rtl/verilog/axil_axis.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/axil_slav.v ./common/caravel_project/rtl/verilog/axil_slav.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/axis_mstr.v ./common/caravel_project/rtl/verilog/axis_mstr.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/axis_slav.v ./common/caravel_project/rtl/verilog/axis_slav.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/buff_flash_clkrst.wire.v ./common/caravel_project/rtl/verilog/buff_flash_clkrst.wire.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/caravel_clocking.wire.v ./common/caravel_project/rtl/verilog/caravel_clocking.wire.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/caravel_logo.wire.v ./common/caravel_project/rtl/verilog/caravel_logo.wire.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/caravel_motto.wire.v ./common/caravel_project/rtl/verilog/caravel_motto.wire.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/caravel_power_routing.wire.v ./common/caravel_project/rtl/verilog/caravel_power_routing.wire.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/chip_io.wire.v ./common/caravel_project/rtl/verilog/chip_io.wire.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/concat_EdgeDetect_Top_fsic.v ./common/caravel_project/rtl/verilog/concat_EdgeDetect_Top_fsic.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/config_ctrl.v ./common/caravel_project/rtl/verilog/config_ctrl.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/constant_block.wire.v ./common/caravel_project/rtl/verilog/constant_block.wire.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/copyright_block.wire.v ./common/caravel_project/rtl/verilog/copyright_block.wire.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/empty_macro.v ./common/caravel_project/rtl/verilog/empty_macro.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/fsic_clkrst.v ./common/caravel_project/rtl/verilog/fsic_clkrst.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/fsic_coreclk_phase_cnt.v ./common/caravel_project/rtl/verilog/fsic_coreclk_phase_cnt.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/fsic_io_serdes_rx.v ./common/caravel_project/rtl/verilog/fsic_io_serdes_rx.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/fsic_mprj_io.v ./common/caravel_project/rtl/verilog/fsic_mprj_io.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/fsic.v ./common/caravel_project/rtl/verilog/fsic.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/gpio_control_block.wire.v ./common/caravel_project/rtl/verilog/gpio_control_block.wire.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/gpio_defaults_block.wire.v ./common/caravel_project/rtl/verilog/gpio_defaults_block.wire.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/gpio_logic_high.wire.v ./common/caravel_project/rtl/verilog/gpio_logic_high.wire.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/gpio_signal_buffering.wire.v ./common/caravel_project/rtl/verilog/gpio_signal_buffering.wire.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/housekeeping_spi.v ./common/caravel_project/rtl/verilog/housekeeping_spi.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/housekeeping.wire.v ./common/caravel_project/rtl/verilog/housekeeping.wire.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/io_serdes.v ./common/caravel_project/rtl/verilog/io_serdes.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/irq_mux.v ./common/caravel_project/rtl/verilog/irq_mux.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/la_mux.v ./common/caravel_project/rtl/verilog/la_mux.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/LogicAnalyzer.v ./common/caravel_project/rtl/verilog/LogicAnalyzer.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/sram_wrapper.v ./common/caravel_project/rtl/verilog/sram_wrapper.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/manual_power_connections.v ./common/caravel_project/rtl/verilog/manual_power_connections.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/mgmt_core.patrick.remove.v ./common/caravel_project/rtl/verilog/mgmt_core.patrick.remove.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/mgmt_core_wrapper.wire.v ./common/caravel_project/rtl/verilog/mgmt_core_wrapper.wire.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/mgmt_protect.wire.v ./common/caravel_project/rtl/verilog/mgmt_protect.wire.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/mprj_io_buffer.wire.v ./common/caravel_project/rtl/verilog/mprj_io_buffer.wire.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/mprj_io.wire.v ./common/caravel_project/rtl/verilog/mprj_io.wire.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/open_source.wire.v ./common/caravel_project/rtl/verilog/open_source.wire.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/spram.wire.v ./common/caravel_project/rtl/verilog/spram.wire.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/Sram.v ./common/caravel_project/rtl/verilog/Sram.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/sw_caravel.v ./common/caravel_project/rtl/verilog/sw_caravel.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/user_id_programming.wire.v ./common/caravel_project/rtl/verilog/user_id_programming.wire.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/user_id_textblock.wire.v ./common/caravel_project/rtl/verilog/user_id_textblock.wire.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/user_prj0.v ./common/caravel_project/rtl/verilog/user_prj0.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/user_prj1.v ./common/caravel_project/rtl/verilog/user_prj1.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/user_prj2.v ./common/caravel_project/rtl/verilog/user_prj2.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/user_prj3.v ./common/caravel_project/rtl/verilog/user_prj3.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/user_project_wrapper.v ./common/caravel_project/rtl/verilog/user_project_wrapper.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/user_subsys.v ./common/caravel_project/rtl/verilog/user_subsys.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/VexRiscv_MinDebug.v ./common/caravel_project/rtl/verilog/VexRiscv_MinDebug.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/xres_buf.wire.v ./common/caravel_project/rtl/verilog/xres_buf.wire.v
cp ../lab_formal_release/common/caravel_project/rtl/verilog/caravel_top.v ./common/caravel_project/rtl/verilog/caravel_top.v
cp ../lab_formal_release/lab_synthesis/system/caravel_post.f ./lab_synthesis/system/caravel_post.f
echo "copy file from lab_formal_release done"


# comment not use command in makefile

sed -i 's|cp lab_formal/script/gen_formality_cmd.tcl.caravel lab_formal/script/gen_formality_cmd.tcl|#cp lab_formal/script/gen_formality_cmd.tcl.caravel lab_formal/script/gen_formality_cmd.tcl   youwei comment it seems not to use for saed32|' makefile
echo "./makefile has been updated."
sed -i 's|all: dir_rtl dir_post run_edge|all: dir_rtl dir_post #run_edge youwei comment delete edge part|' ./lab_synthesis/makefile
echo "./lab_synthesis/makefile has been updated."