rm -rf upload results reports lab_synthesis input common README.md makefile make_saed32_all.log
